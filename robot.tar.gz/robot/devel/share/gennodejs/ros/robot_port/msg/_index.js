
"use strict";

let vmap = require('./vmap.js');
let Person = require('./Person.js');
let stop = require('./stop.js');
let response = require('./response.js');
let path = require('./path.js');
let voice_cmd = require('./voice_cmd.js');
let Frame = require('./Frame.js');
let posi = require('./posi.js');
let Pixel = require('./Pixel.js');
let enum_type = require('./enum_type.js');
let map_object = require('./map_object.js');
let BodyPart = require('./BodyPart.js');
let point_2d = require('./point_2d.js');
let path_ori = require('./path_ori.js');

module.exports = {
  vmap: vmap,
  Person: Person,
  stop: stop,
  response: response,
  path: path,
  voice_cmd: voice_cmd,
  Frame: Frame,
  posi: posi,
  Pixel: Pixel,
  enum_type: enum_type,
  map_object: map_object,
  BodyPart: BodyPart,
  point_2d: point_2d,
  path_ori: path_ori,
};

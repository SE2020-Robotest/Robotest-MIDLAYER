// Auto-generated. Do not edit!

// (in-package robot_port.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let point_2d = require('./point_2d.js');

//-----------------------------------------------------------

class path_ori {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.start_time = null;
      this.end_time = null;
      this.p = null;
    }
    else {
      if (initObj.hasOwnProperty('start_time')) {
        this.start_time = initObj.start_time
      }
      else {
        this.start_time = 0.0;
      }
      if (initObj.hasOwnProperty('end_time')) {
        this.end_time = initObj.end_time
      }
      else {
        this.end_time = 0.0;
      }
      if (initObj.hasOwnProperty('p')) {
        this.p = initObj.p
      }
      else {
        this.p = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type path_ori
    // Serialize message field [start_time]
    bufferOffset = _serializer.float64(obj.start_time, buffer, bufferOffset);
    // Serialize message field [end_time]
    bufferOffset = _serializer.float64(obj.end_time, buffer, bufferOffset);
    // Serialize message field [p]
    // Serialize the length for message field [p]
    bufferOffset = _serializer.uint32(obj.p.length, buffer, bufferOffset);
    obj.p.forEach((val) => {
      bufferOffset = point_2d.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type path_ori
    let len;
    let data = new path_ori(null);
    // Deserialize message field [start_time]
    data.start_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [end_time]
    data.end_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [p]
    // Deserialize array length for message field [p]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.p = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.p[i] = point_2d.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 16 * object.p.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robot_port/path_ori';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8e66f1ef25eaeb49239ebf86f3843894';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 start_time
    float64 end_time
    point_2d[] p
    
    ================================================================================
    MSG: robot_port/point_2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new path_ori(null);
    if (msg.start_time !== undefined) {
      resolved.start_time = msg.start_time;
    }
    else {
      resolved.start_time = 0.0
    }

    if (msg.end_time !== undefined) {
      resolved.end_time = msg.end_time;
    }
    else {
      resolved.end_time = 0.0
    }

    if (msg.p !== undefined) {
      resolved.p = new Array(msg.p.length);
      for (let i = 0; i < resolved.p.length; ++i) {
        resolved.p[i] = point_2d.Resolve(msg.p[i]);
      }
    }
    else {
      resolved.p = []
    }

    return resolved;
    }
};

module.exports = path_ori;

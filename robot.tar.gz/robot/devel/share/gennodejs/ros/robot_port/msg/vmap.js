// Auto-generated. Do not edit!

// (in-package robot_port.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let map_object = require('./map_object.js');

//-----------------------------------------------------------

class vmap {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.w = null;
      this.h = null;
      this.obj = null;
    }
    else {
      if (initObj.hasOwnProperty('w')) {
        this.w = initObj.w
      }
      else {
        this.w = 0.0;
      }
      if (initObj.hasOwnProperty('h')) {
        this.h = initObj.h
      }
      else {
        this.h = 0.0;
      }
      if (initObj.hasOwnProperty('obj')) {
        this.obj = initObj.obj
      }
      else {
        this.obj = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type vmap
    // Serialize message field [w]
    bufferOffset = _serializer.float64(obj.w, buffer, bufferOffset);
    // Serialize message field [h]
    bufferOffset = _serializer.float64(obj.h, buffer, bufferOffset);
    // Serialize message field [obj]
    // Serialize the length for message field [obj]
    bufferOffset = _serializer.uint32(obj.obj.length, buffer, bufferOffset);
    obj.obj.forEach((val) => {
      bufferOffset = map_object.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type vmap
    let len;
    let data = new vmap(null);
    // Deserialize message field [w]
    data.w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [h]
    data.h = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obj]
    // Deserialize array length for message field [obj]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.obj = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.obj[i] = map_object.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 33 * object.obj.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robot_port/vmap';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cbb693fd6d423b3a6cad4b88949301d1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 w
    float64 h
    map_object[] obj
    
    ================================================================================
    MSG: robot_port/map_object
    bool type
    float64 x
    float64 y
    float64 w
    float64 h
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new vmap(null);
    if (msg.w !== undefined) {
      resolved.w = msg.w;
    }
    else {
      resolved.w = 0.0
    }

    if (msg.h !== undefined) {
      resolved.h = msg.h;
    }
    else {
      resolved.h = 0.0
    }

    if (msg.obj !== undefined) {
      resolved.obj = new Array(msg.obj.length);
      for (let i = 0; i < resolved.obj.length; ++i) {
        resolved.obj[i] = map_object.Resolve(msg.obj[i]);
      }
    }
    else {
      resolved.obj = []
    }

    return resolved;
    }
};

module.exports = vmap;
